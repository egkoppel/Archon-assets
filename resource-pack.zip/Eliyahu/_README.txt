LoKiCraft PureCartoonPack 128x @2016 

created by _LoKi_ (M_LoKi_G)

http://www.planetminecraft.com/member/_loki_/


====================================================================================================

Thank you for downloading this Resource Pack.

This is my own texture pack and I'm working on it for couple weeks now. I will update it minimum one time a week (or I'll just try do this :V ).   

NOTE: This pack is created for version 1.9+ and might not work on earlier Minecraft releases (1.8 and older)


I hope you'll enjoy my modest resource pack ;)

Happy Mining!!

=====================================LICENSE=========================================================

LoKiCraft PureCartoonPack by _LoKi_ is licensed under a Creative Commons Attribution-NonCommercial License.  

